package FinalProject;

import FinalProject.lexer.*;
import FinalProject.node.*;
import FinalProject.parser.*;
import java.io.*;

public class SymbolTE{
	public String name;
	public String type; //or return type
	
}